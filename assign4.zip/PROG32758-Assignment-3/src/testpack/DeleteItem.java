package testpack;


import java.io.IOException;


import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/DeleteItem")
public class DeleteItem extends HttpServlet {

	private static final long serialVersionUID = 1L;
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		

		@SuppressWarnings("unused")
		String msg = "";
		if(request.getParameter("msg") != null) msg = request.getParameter("msg");
		

		RequestDispatcher rd = request.getRequestDispatcher("/WEB-INF/pages/deleteitem.jsp"); //forward the servlet to the deleteitem page in pages, then pages calls the actual delete item jsp page
		rd.forward(request, response);
		

		/*	out.println(OurUtilities.getHtmlHeader("Delete Item Page"));
			out.println("<form method=post>");
			out.println("<h2>Delete Item</h2>");
			out.println("<h3 style=\"color:red;\">"+msg+"</h3>");
			out.println("<input type=submit value=Delete>");
			out.println("</form>");
			out.println(OurUtilities.getHtmlFooter()); */
		} 
	
	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html");
//		PrintWriter out = response.getWriter();
		Integer uid = (Integer)request.getSession().getAttribute("uid");
		if(uid == null) {
			// user did not login, send him to the login page
			response.sendRedirect("Login?msg=you have to login first");
		} else {
		String itemid=request.getParameter("iid"); //retrieve the item id
		int iid=Integer.parseInt(itemid); //parse it to an integer
		
		Item i = new Item(iid); //create an instance of the item constructo and pass iid
		DB_Access db = new DB_Access();
		int result=db.deleteItem(i, uid); //local variable to call the method and add uid as a param too as its in the sessin
		

			switch(result) {
			case 0:
				response.sendRedirect("Home?iid="+i.getId()+"msg=deleted successfully"); //i deciided not to display this msg in the webpage but in the browser instead and redirect to home servlet
				break;
			}
	//	doGet(request, response);
		
		}
}
}