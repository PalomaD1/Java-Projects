package testpack;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


@WebServlet("/UpdateAccount")
public class UpdateAccount extends HttpServlet {
	private static final long serialVersionUID = 1L;
     

	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html");
		
		@SuppressWarnings("unused")
		String msg = "";//create a msg varaible in doget method
		if(request.getParameter("msg") != null)  //if the msg is not equal to null in the msg parameter as defined in dopost
			msg = request.getParameter("msg");//set the local variale to the msg parameter, and then display it in the jsp page using ${param.msg}
		
		@SuppressWarnings("unused")
		String lname = "", fname = ""; //these are string variables
		
		Cookie [] all = request.getCookies(); //cookie arraylist
		if(all != null) { //if there are cookies stored
			for(Cookie c : all) { //for each cookie in the arraylist of cookie
				if(c.getName().equals("lname")) //if there is a loginname
				{ 
					lname = c.getValue();
				}
				else if(c.getName().equals("fname")) { //if there is a passwrod
					fname = c.getValue();
				}
				
				
				
			}//end for
		}//end big if
		
		RequestDispatcher rd = request.getRequestDispatcher("/WEB-INF/pages/updateaccount.jsp");
		rd.forward(request, response);
	
		}
		
	

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String userid=request.getParameter("uid");
		int uid=Integer.parseInt(userid);//retrieve the uid param
		String lName = request.getParameter("lname"); //retrieve lname from updateaccount.jsp
		String fName = request.getParameter("fname"); //retrieve fname from updateaccount.jsp
		String lpass1 = request.getParameter("lpass1"); //retrieve lpass1 "
		String lpass2 = request.getParameter("lpass2"); //retrieve lapss2 "
		User u = new User(uid, lName, fName, lpass1, lpass2);
		DB_Access db = new DB_Access();
		int result = db.updateAccount(u);
		
		Cookie loginNameCookie = new Cookie("lname", lName); //add these local variavles to the cookies for both loginname and fullname
		Cookie fullNameCookie = new Cookie("fname", fName);
		response.addCookie(loginNameCookie);
		response.addCookie(fullNameCookie);
		
		switch(result) {
		case 0:
		//	response.sendRedirect("LoginForm?uid="+ u.getUid()+ "msg=account has been updated, login now");
			response.sendRedirect("Login?msg=account has been updated, login now"); //there were no problems
			break;
		case 1: 
			response.sendRedirect("UpdateAccount?msg=values are too long, try again");
			break;
		case 2:
			response.sendRedirect("UpdateAccount?msg=choose another login name, this one is taken");
			break;
		case 3:
			response.sendRedirect("UpdateAccount?msg=all values must be provided, try again");
			break;
		case 4:
			response.sendRedirect("UpdateAccount?msg=passwords are not the same, try gain");
			break;
		}
	//	doGet(request, response);
	}

}
