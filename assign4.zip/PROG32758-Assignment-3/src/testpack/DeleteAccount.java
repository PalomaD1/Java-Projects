package testpack;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import testpack.DB_Access;
import testpack.User;

/**
 * Servlet implementation class DeleteAccount
 */
@WebServlet("/DeleteAccount")
public class DeleteAccount extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
  
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		@SuppressWarnings("unused")
		String msg = "";
		if(request.getParameter("msg") != null) msg = request.getParameter("msg");
		

		RequestDispatcher rd = request.getRequestDispatcher("/WEB-INF/pages/deleteaccount.jsp");//forward the servlet to the deleteaccount jsp page in pages
		rd.forward(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		String userid=request.getParameter("uid"); //get the uid param and save it in a string, and call the getparam method for request object
		int uid=Integer.parseInt(userid); //parse the string variable to an int as per constructor rules
		
		User u = new User(uid); //created a new one argument constructor
		DB_Access db = new DB_Access(); //create a new dbaccess object called db
		int result=db.deleteAccount(u);//create a new int variable and call the delete account method
		

			switch(result) {
			case 0: //as in, if everythng is fine our case is zero so
			//	response.sendRedirect("Login?uid="+u.getUid()+"msg=deleted successfully"); //send a redirect to login form
				response.sendRedirect("Login?msg=account has been deleted successfully");
				break;
			}
	//	doGet(request, response);
	}

}
