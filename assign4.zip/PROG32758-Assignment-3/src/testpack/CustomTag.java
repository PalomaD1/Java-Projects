package testpack;


import java.io.IOException; //mandatory imports, exception

import javax.servlet.jsp.JspException; //jsp exc
import javax.servlet.jsp.JspWriter; //jsp writer
import javax.servlet.jsp.tagext.SimpleTagSupport; //simple tag support tag

public class CustomTag extends SimpleTagSupport { //extends simpletagsupport 

	private String c; //field var
	
	public void setColor(String c) { //setter 
		this.c = c;
	}
	
	@Override
	public void doTag() throws JspException, IOException { //dotag throws these two exceptions
		// TODO Auto-generated method stub
		super.doTag(); //super.doTag method calls the superclass method
		JspWriter out = getJspContext().getOut(); //create out obj
		out.print("<p style=\"color:"+c+"\"> Nice to see you, </p>"); //print the heading
	}
}