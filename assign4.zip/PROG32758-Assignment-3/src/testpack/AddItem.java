package testpack; //our package


import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/AddItem") //servlet name
public class AddItem extends HttpServlet {
	
	private static final long serialVersionUID = 1L; //the serial version UID is 1L
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		@SuppressWarnings("unused") //prevents computer from throwing a warning that variables unused
		String msg = ""; //msg variable
		if(request.getParameter("msg") != null) msg = request.getParameter("msg"); //if msg is not equal to null then get the msg variable param
		

		RequestDispatcher rd = request.getRequestDispatcher("/WEB-INF/pages/additem.jsp"); //create an object of requestdispatcher to forward the servlet to additem.jsp in pages to throw the predefined css styles
		rd.forward(request, response); //forward the request and response object
		
	}
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html");
		//PrintWriter out = response.getWriter();
		
		Integer uid = (Integer)request.getSession().getAttribute("uid"); //get the uid session attribute
		
		if(uid == null) {
			// user did not login, send him to the login page
			response.sendRedirect("Login?msg=you have to login first");
		} else {
			String iname = request.getParameter("iname");//get the iname parameter from the jsp page in snippets
			String iqty = request.getParameter("iqty"); //get the iqty parameter from the jsp page in snippets
			DB_Access db = new DB_Access(); //create an object of the DB Access class to throw the methods
			int res = db.addItem(iname, iqty, uid); //create local variable with the iname, iqty and the uid parameter(from session attribute)
			// 0 - OK - item was inserted
			// 1 - item name was not given
			// 2 - item qty was either not given or not a valid int
			switch(res) { //what to do if each one of the following scenarios happens
			case 0:
				response.sendRedirect("Home");
				break;
			case 1:
				response.sendRedirect("AddItem?msg=item name must be provided");
				break;
			case 2:
				response.sendRedirect("AddItem?msg=item quantity must be provided and must be an integer");
				break;
			}//end else
		}//end big if
	}///end methhod

}//end class

