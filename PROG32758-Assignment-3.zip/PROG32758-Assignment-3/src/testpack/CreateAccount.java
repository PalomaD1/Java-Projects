package testpack;

import java.io.IOException;


import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import testpack.DB_Access;

import testpack.User;



@WebServlet("/CreateAccount")
public class CreateAccount extends HttpServlet {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	
	@SuppressWarnings("unused")
	String msg = "";
	if(request.getParameter("msg") != null) msg = request.getParameter("msg");
	

	RequestDispatcher rd = request.getRequestDispatcher("/WEB-INF/pages/createaccount.jsp"); //the servlet displays the createaccount jsp ile in pages folder, that then links to the snippets createaccount page
	rd.forward(request, response); //forward the req and res objects
	
	}
	
	
	


protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	// 0 means everything is OK, user is created
	// 1 means values are too long
	// 2 means unique constraint on the login name has been violated
	// 3 means that an empty form field was submitted
	// 4 means that the passwords are not the same
	String lName = request.getParameter("lname");//get the lname parameter from jsp snippets createaccount page
	String fName = request.getParameter("fname"); //get the fname parameter from jsp snippets createaccount page
	String lPass1 = request.getParameter("lpass1");//get lpass1 from jsp snippets createaccount page
	String lPass2 = request.getParameter("lpass2");//get lpass2 from jsp snippets createaccount page
	User u = new User(-1, lName, fName, lPass1, lPass2); //create a five arg constructor to pass the values includeing a placeholder for uid
	DB_Access db = new DB_Access();
	int result = db.createUserAccount(u); //call the createaccount method in DBAccess
	
	Cookie loginNameCookie = new Cookie("lname", lName); //add the local variable to the cookie
	Cookie fullNameCookie = new Cookie("fname", fName); //add the local variable to the cookie
	response.addCookie(loginNameCookie);
	response.addCookie(fullNameCookie);
	
	switch(result) {
	case 0:
		response.sendRedirect("Login?msg=account has been created, login now"); //redirect to the login page if everything is fine
		break;
	case 1: 
		response.sendRedirect("CreateAccount?msg=values are too long, try again");
		break;
	case 2:
		response.sendRedirect("CreateAccount?msg=chose another login name, this one is taken");
		break;
	case 3:
		response.sendRedirect("CreateAccount?msg=all values must be provided, try again");
		break;
	case 4:
		response.sendRedirect("CreateAccount?msg=passwords are not the same, try gain");
		break;
	}
}

}