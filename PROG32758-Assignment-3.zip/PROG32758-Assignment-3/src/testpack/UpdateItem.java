package testpack;


import java.io.IOException;//the various import statements


import javax.servlet.RequestDispatcher;
//import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
//import javax.servlet.http.HttpSession;


@WebServlet("/UpdateItem")//the name of the servlet
public class UpdateItem extends HttpServlet {
	private static final long serialVersionUID = 1L; //serial id
       
    

	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {//the doget method
		
		
		Integer uid = (Integer)request.getSession().getAttribute("uid");
		
		if(uid == null) {
			// user did not login, send him to the login page
			response.sendRedirect("Login?msg=you have to login first"); //pass this msg to msg parameter
		} else {
		
			@SuppressWarnings("unused")
			String msg = "";
			if(request.getParameter("msg") != null) msg = request.getParameter("msg");//if the msg actually says something then get the parameter
			

			RequestDispatcher rd = request.getRequestDispatcher("/WEB-INF/pages/updateitem.jsp"); //forward the webpage to the updateitem page in pages
			rd.forward(request, response);
	
			
		}
		} 

	

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html");
//		PrintWriter out = response.getWriter();
		
		Integer uid = (Integer)request.getSession().getAttribute("uid");
		if(uid == null) {
			// user did not login, send him to the login page
			response.sendRedirect("Login?msg=you have to login first");
		} else {
		String itemid=request.getParameter("iid");//get the iid parameter
		int iid=Integer.parseInt(itemid); ///parse as per constructor rules
		
		String iname = request.getParameter("iname"); //get the iname parameter from the updateitem.jsp	
		String iqty = request.getParameter("iqty");//get the iqty parameter from updateitem.jsp
		
	//	try{
		int qty=Integer.parseInt(iqty);//parse qty to integer
		Item i = new Item(iid,iname, qty);
		DB_Access db = new DB_Access();
		
		int result = db.updateItem(i,uid); //create a local result variable and call item id at this uid
		
		Cookie NameCookie = new Cookie("name", iname);
		Cookie QtyCookie = new Cookie("iqty", iqty);
		
		response.addCookie(NameCookie);
		response.addCookie(QtyCookie);
	
		switch(result) {
		case 0:
			response.sendRedirect("Home?iid="+i.getId()+"msg=updated successfully");//if there were no problems
			//out.println("<td><a href=UpdateItem?iid="+i.getId()+">Update</a> <a href=DeleteItem?iid="+i.getId()+">Delete</a></td>"); //this is at item i
			break;
		case 1: 
			response.sendRedirect("UpdateItem?iid="+i.getId()+"msg=item name must be provided");
			break;
		case 2:
			response.sendRedirect("UpdateItem?iid="+i.getId()+"msg=item quantity must be provided and must be an integer");
			break;
		} //end switch
		
		
	//	}catch(NumberFormatException ex){
		//	response.sendRedirect("UpdateItem?msg=item quantity must be provided and must be an integer");
	//	}
		
	
		} //end else
		
	}//end method
} //end class 

	

		