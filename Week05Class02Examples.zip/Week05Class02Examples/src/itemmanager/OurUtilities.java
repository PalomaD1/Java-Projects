package itemmanager;

public class OurUtilities {
	public static String getHtmlHeader(String ttl) {
		return "<html><head><title>"+ttl+"</title></head><body><center>";
	}
	public static String getHtmlFooter() {
		return "</center></body></html>";
	}
	public static boolean validateTextInput(String val) {
		boolean valid = true;
		if(val == null ||  val.trim().equals("")) valid = false;
		return valid;
	}
}
