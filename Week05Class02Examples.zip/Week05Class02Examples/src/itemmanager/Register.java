package itemmanager;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/Register")
public class Register extends HttpServlet {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html");
		PrintWriter out = response.getWriter();
		
		String msg = "";
		if(request.getParameter("msg") != null) msg = request.getParameter("msg");
		
		String lname = "", fname = "";
		
		Cookie [] all = request.getCookies();
		if(all != null) {
			for(Cookie c : all) {
				if(c.getName().equals("lname")) lname = c.getValue();
				else if(c.getName().equals("fname")) fname = c.getValue();
			}
		}
		
		out.println(OurUtilities.getHtmlHeader("Register Account Page"));
		out.println("<form method=post>");
		out.println("<h2>Create An Account</h2>");
		out.println("<h3 style=\"color:red;\">"+msg+"</h3>");
		out.println("Login Name: <input type=text value=\""+lname+"\" name=lname><br>");
		out.println("Full Name: <input type=text value=\""+fname+"\" name=fname><br>");
		out.println("Password: <input type=password name=lpass1><br>");
		out.println("Repeat Password: <input type=password name=lpass2><br>");
		out.println("<input type=submit value=Create>");
		out.println("</form>");
		out.println(OurUtilities.getHtmlFooter());
		
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// 0 means everything is OK, user is created
		// 1 means values are too long
		// 2 means unique constraint on the login name has been violated
		// 3 means that an empty form field was submitted
		// 4 means that the passwords are not the same
		String lName = request.getParameter("lname");
		String fName = request.getParameter("fname");
		String lPass1 = request.getParameter("lpass1");
		String lPass2 = request.getParameter("lpass2");
		User u = new User(-1, lName, fName, lPass1, lPass2);
		DB_Access db = new DB_Access();
		int result = db.createUserAccount(u);
		
		Cookie loginNameCookie = new Cookie("lname", lName);
		Cookie fullNameCookie = new Cookie("fname", fName);
		response.addCookie(loginNameCookie);
		response.addCookie(fullNameCookie);
		
		switch(result) {
		case 0:
			response.sendRedirect("LoginForm?msg=account has been created, login now");
			break;
		case 1: 
			response.sendRedirect("Register?msg=values are too long, try again");
			break;
		case 2:
			response.sendRedirect("Register?msg=chose another login name, this one is taken");
			break;
		case 3:
			response.sendRedirect("Register?msg=all values must be provided, try again");
			break;
		case 4:
			response.sendRedirect("Register?msg=passwords are not the same, try gain");
			break;
		}
	}

}








