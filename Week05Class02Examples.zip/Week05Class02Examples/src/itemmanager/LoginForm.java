package itemmanager;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/LoginForm")
public class LoginForm extends HttpServlet {
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html");
		PrintWriter out = response.getWriter();
		
		String msg = "";
		if(request.getParameter("msg") != null) msg = request.getParameter("msg");
		
		out.println(OurUtilities.getHtmlHeader("login form"));
		out.println("<h2>Login</h2>");
		out.println("<h3 style=\"color:red;\">"+msg+"</h3>");
		out.println("<form method=post>");
		out.println("Login Name: <input type=text name=lname><br>");
		out.println("Password: <input type=password name=lpass><br>");
		out.println("<input type=submit value=Login><br>");
		out.println("</form>");
		out.println("<a href=Register>Register an Account</a>");
		out.println(OurUtilities.getHtmlFooter());
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		boolean canCheck = true;
		String lname = request.getParameter("lname");
		String lpass = request.getParameter("lpass");
		canCheck = OurUtilities.validateTextInput(lname);
		if(canCheck) canCheck = OurUtilities.validateTextInput(lpass);
		if(canCheck) {
			// both user name and password values passed the validation, send them to the database for verification
			DB_Access db = new DB_Access();
			int uid = db.validateLogin(lname, lpass);
			if(uid != -1) {
				// valid user, we found a match in the table for the give lname and lpass values
				request.getSession().setAttribute("uid", uid);
				response.sendRedirect("Home");
			}
			else {
				// either lname or lpass (or both) is invalid, redisplay the login form with a message
				response.sendRedirect("LoginForm?msg=either login name or password is wrong");
			}
		}
		else {
			// either user name or password did not pass validation, redisplay the form and show the error message
			response.sendRedirect("LoginForm?msg=invalid values for either user name or password");
		}
	}
}








