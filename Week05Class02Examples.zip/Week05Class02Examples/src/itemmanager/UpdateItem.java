package itemmanager;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


@WebServlet("/UpdateItem.do")
public class UpdateItem extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    
    public UpdateItem() {
        super();
        
    }

	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html");
		PrintWriter out = response.getWriter();
		
		Integer uid = (Integer)request.getSession().getAttribute("uid");
		if(uid == null) {
			// user did not login, send him to the login page
			response.sendRedirect("LoginForm?msg=you have to login first");
		} else {
			String msg = "";
			if(request.getParameter("msg") != null) msg = request.getParameter("msg");
			out.println(OurUtilities.getHtmlHeader("Update Item Page"));
			out.println("<h2>Update Item</h2>");
			out.println("<h3 style=\"color:red;\">"+msg+"</h3>");
			out.println("<form method=post>");
			out.println("Item Name: <input type=text name=iname><br>");//iname s the first textbox
			out.println("Item Quantity: <input type=text name=iqty><br>");//iqty is my second textbox
			out.println("<input type=submit value=Create>");
			out.println("</form>");
			out.println(OurUtilities.getHtmlFooter());
			
		} 
		}
	

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html");
		PrintWriter out = response.getWriter();
		
		Integer uid = (Integer)request.getSession().getAttribute("uid");
		
		if(uid == null) {
			// user did not login, send him to the login page
			response.sendRedirect("LoginForm?msg=you have to login first");
		} else {
			String iname = request.getParameter("iname");//the first textbox
			String iqty = request.getParameter("iqty");//the second textbox
			DB_Access db = new DB_Access();
			int res = db.updateItem(iname, iqty, uid);///wait a second. can i maybe pass 4 PARAMS here?? from the update item page. it just might make it easier
			// 0 - OK - item was inserted
			// 1 - item name was not given
			// 2 - item qty was either not given or not a valid int
			switch(res) {
			case 0:
				response.sendRedirect("Home");
				break;
			case 1:
				response.sendRedirect("UpdateItem?msg=item name must be provided");
				break;
			case 2:
				response.sendRedirect("UpdateItem?msg=item quantity must be provided and must be an integer");
				break;
			}
				
	} 

}
	}

		
	

