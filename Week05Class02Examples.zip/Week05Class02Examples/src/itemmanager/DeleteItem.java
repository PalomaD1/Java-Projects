package itemmanager;


import java.io.IOException;
import java.io.PrintWriter;
import java.sql.ResultSet;
import java.util.ArrayList;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/DeleteItem")
public class DeleteItem extends HttpServlet {

	private static final long serialVersionUID = 1L;
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html");
		PrintWriter out = response.getWriter();
		
		Integer uid = (Integer)request.getSession().getAttribute("uid");
		if(uid == null) {
			// user did not login, send him to the login page
			response.sendRedirect("LoginForm?msg=you have to login first");
		} else {
			String msg = "";
			if(request.getParameter("msg") != null) msg = request.getParameter("msg");
		} 
	}
	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html");
		PrintWriter out = response.getWriter();
		
		Integer uid = (Integer)request.getSession().getAttribute("uid");
		
		DB_Access db=new DB_Access();
		if(uid == null) {
			// user did not login, send him to the login page
			response.sendRedirect("LoginForm?msg=you have to login first");
		} else {
			
			Item i = new Item();
			db.deleteItem(i, uid);
			response.sendRedirect("Home");
		
		}
		}
}
