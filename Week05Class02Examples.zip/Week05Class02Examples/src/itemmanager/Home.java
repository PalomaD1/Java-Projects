package itemmanager;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/Home")
public class Home extends HttpServlet {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html");
		PrintWriter out = response.getWriter();
		
		Integer uid = (Integer)request.getSession().getAttribute("uid");
		
		if(uid == null) {
			// user did not login, send him to the login page
			response.sendRedirect("LoginForm?msg=you have to login first");
		} else {
			DB_Access db = new DB_Access();
			String uname = db.getUserName(uid);
			ArrayList<Item> all = db.getAllUserItems(uid);
			
			out.println(OurUtilities.getHtmlHeader("Home Page"));
			out.println("<table width='80%'><tr><td><h2>Welcome: "+uname+"</h2></td><td align=right><a href=UpdateAccount>Update Account</a>  <a href=LogOut>LogOut</a></td></tr></table>");
			
			out.println("<h2>All User Items</h2>");
			out.println("<table>");
			out.println("<tr><th></th><th>Name:</th><th>Quantity:</th></tr>");
			
			for(Item i : all) {
				out.println("<tr>");
			//	out.println("<tr href='UpdateItem'> ");
			
			  //   out.println(" <td>UpdateItem</td>");
			  //  out.println("</tr>");
			  //  out.println("<tr href='DeleteItem'> ");
				
			  //   out.println(" <td>DeleteItem</td>");
			 //   out.println("</tr>");
			    
				
			//	out.println("<td><a href=UpdateItem>Update</a> </td>");
			//	out.println("<a href=DeleteItem>Delete</a></td>");
				out.println("<td><a href=UpdateItem.do?iid="+i.getId()+">Update</a> <a href=DeleteItem?iid="+i.getId()+">Delete</a></td>");
				out.println("<td>"+i.getName()+"</td>");
				out.println("<td>"+i.getQty()+"</td>");
				out.println("</tr>");
			}
			
			out.println("</table>");
			out.println("<a href=AddItem>Add New Item</a>");
			
			out.println(OurUtilities.getHtmlFooter());			
		}
		}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	}
}
