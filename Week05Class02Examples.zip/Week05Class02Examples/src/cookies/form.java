package cookies;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/form")
public class form extends HttpServlet {
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html");
		PrintWriter out = response.getWriter();
		out.println("<center><form method=post><h2>Select a color</h2>");
		out.println("<select name=color>");
		out.println("<option value=red>Color Red</option>");
		out.println("<option value=green>Color Green</option>");
		out.println("<option value=blue>Color Blue</option>");
		out.println("</select>");
		out.println("<input type=submit value=send></form><br>");
		out.println("<h2><a href=ExpireCookie>Expire Cookie</a></h2></center>");
	}
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String color = request.getParameter("color");
		//Cookie c = new Cookie("color", color); // default cookie duration is session
		Cookie c = new Cookie("color", color); // persistent cookie
		c.setMaxAge(60 * 60 * 24 * 365); // value in seconds
		response.addCookie(c);
		response.sendRedirect("UseCookie");
	}
}
