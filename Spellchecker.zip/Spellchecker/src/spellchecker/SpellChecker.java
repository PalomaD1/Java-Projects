/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package spellchecker;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.io.File;
import java.io.FileInputStream;
import java.util.Scanner;


/**
 *
 * @author guest1
 */
public class SpellChecker { 
    
    public static void main(String[] args) throws IOException, Exception {
      /*spellcheck input file dictionary file*/
   getUserInput();
   
  
}

    public static void getUserInput() throws IOException, Exception {
       
       System.out.println("You must save the files before using this program. The path to save the file is:");
   System.out.println("\\Documents\\Spellchecker\\src"); 
       System.out.println("Type the word spellcheck before the input file and followed by the dictionary file");
   System.out.println("example: spellcheck inputfile dictionaryfile");
    System.out.println("Type the input file name with the extension");
    Scanner userinput1=new Scanner(System.in);
    String input=userinput1.next();
   System.out.println("Type the dictionary file name with the extension");
    Scanner userinput2=new Scanner(System.in);
    String dictionary=userinput2.next();
     System.out.println("spellcheck " + input + " " + dictionary);
     System.out.println(" ");
     
     checkUserInput();
    
    }

    private static void checkUserInput() throws FileNotFoundException, IOException, Exception {
        
        BufferedReader reader2;
        try (BufferedReader reader1 = new BufferedReader(new FileReader("C:\\Users\\guest1\\Documents\\NetBeansProjects\\Spellchecker\\src\\spellchecker\\inputfile.txt"))) {
            reader2 = new BufferedReader(new FileReader("C:\\Users\\guest1\\Documents\\NetBeansProjects\\Spellchecker\\src\\spellchecker\\dictionary.txt"));
            String line1 = reader1.readLine();
            String line2 = reader2.readLine();
            boolean areEqual = true;
            int lineNum = 1;
            while (line1 != null || line2 != null)
            {
                if(line1 == null || line2 == null)
                {
                    areEqual = false;
                    
                    break;
                }
                else if(! line1.equalsIgnoreCase(line2))
                {
                    areEqual = false;
                    
                    break;
                }
                
                line1 = reader1.readLine();
                
                line2 = reader2.readLine();
                
                lineNum++;
            }   if(areEqual)
            {
                System.out.println("There are no spelling mistakes.");
            }
            else
            {
                System.out.println("The following words are misspelled at Line "+lineNum + "." + "These are the misspelled words:");
                
                
            }
        }
         
        reader2.close();
        
        validateInput();
    }
    


    private static void validateInput() throws Exception{

         File f1 = new File("C:\\\\Users\\\\guest1\\\\Documents\\\\NetBeansProjects\\\\Spellchecker\\\\src\\\\spellchecker\\\\inputfile.txt");
      File f2 = new File("C:\\\\Users\\\\guest1\\\\Documents\\\\NetBeansProjects\\\\Spellchecker\\\\src\\\\spellchecker\\\\dictionary.txt");
      
      FileInputStream fi1=new FileInputStream(f1);
    FileInputStream fi2=new FileInputStream(f2); 
    
    Scanner sc2;
            try (Scanner sc1 = new Scanner(fi1)) {
                sc2 = new Scanner(fi2);
                 
                  System.out.println(" ");
                while (sc1.hasNext() && sc2.hasNext()) {
                    String str1 = sc1.next();
                    String str2 = sc2.next();
                  
                    if (!str1.equals(str2))
                        System.out.println(str1 + "\n"+ "\nDo you mean: \n" + str2 + "\n");
                   
                }          
   
}
        }
        
        
    }
    
    
    
